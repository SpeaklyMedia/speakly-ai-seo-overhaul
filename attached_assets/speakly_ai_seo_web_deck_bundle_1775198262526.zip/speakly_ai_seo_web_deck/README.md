# Speakly AI-SEO Overhaul web deck

## Files
- `index.html` — standalone customer-facing web deck
- `speakly-ai-seo-copy-kit.md` — reusable copy for footer, service page, and supporting promo placements

## Recommended use
- Publish `index.html` as a non-nav sales deck or dedicated service landing page.
- Pull the footer/service-page snippets from the copy kit for lighter touch placements elsewhere on the Speakly site.
- Swap CTA links or email addresses before publishing if needed.

## Notes
- This deck is intentionally non-technical. It sells the business value and system logic without exposing proprietary implementation detail.
- Market references in the deck are sourced in the final CTA panel.
- The proof section is adapted from Speakly’s existing explainer deck.
